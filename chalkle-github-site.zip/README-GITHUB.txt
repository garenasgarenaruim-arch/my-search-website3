# GitHub Pages note

Created from the uploaded source:
- index.html
- style.css
- script.js
- appcore.js (placeholder — source not included in upload)
- theme.js (placeholder — source not included in upload)

IMPORTANT:
The original HTML references many additional files under `src/` and `assets/` (games.js, apps.js,
launcher.js, images, fonts, etc.). Those files were not included in the uploaded source, so this
package is the clean split of what was actually provided, not a complete standalone copy.

To make the whole site work on GitHub Pages, upload the missing `src/` and `assets/` directories
from the original website/project as well.
